/*
 Este exemplo mostra como converter uma string em
 um valor do tipo integer.
   
 Cuidado: este exemplo pode lan�ar tr�s tipos de
 exce��es: ArgumentNullException, FormatException
 e OverflowException.
*/

static void Main(string[] args){

  string valorTexto = "530";
  
  // experimente com os valores "23.5", "arquivo" e
  // "659"

  // tenta efetuar a convers�o de string para integer
  try{
    int valorInteiro = int.Parse(valorTexto);
    // exibe o resultado
    Console.WriteLine(valorInteiro);
  }
  catch(FormatException e){
    // exibe a informa��es sobre a exce��o
    // Input string was not in a correct format. 
    Console.WriteLine(e.Message);
  }
 
  Console.WriteLine("Pressione uma tecla para sair...");
  Console.ReadKey();
}
